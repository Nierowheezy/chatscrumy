import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { ScrumdataService } from "../scrumdata.service";
import {
  CdkDragDrop,
  moveItemInArray,
  transferArrayItem
} from "@angular/cdk/drag-drop";

@Component({
  selector: "app-scrumboard",
  templateUrl: "./scrumboard.component.html",
  styleUrls: ["./scrumboard.component.css"]
})
export class ScrumboardComponent implements OnInit {
  tftw = ["Learn Django", "Learn Python", "Learn PHP"];
  tftd = ["Learn Desing"];
  verify = ["Learn Linux", "Learn Ansible"];
  done = ["Full Stack"];

  constructor(
    private _route: ActivatedRoute,
    private _scrumdataService: ScrumdataService
  ) {}

  project_id = 0;
  _participants = [];

  ngOnInit() {
    this.project_id = parseInt(this._route.snapshot.paramMap.get("project_id"));
    this.getProjectGoals();
    // this.verify.push("pushed");
    console.log(this.verify);
    this.sortGoalSet();
  }

  drop(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
    } else {
      transferArrayItem(
        event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
    }
  }

  sortGoalSet() {
    for (let participant of this._participants) {
      for (let goal of this._participants["scrumgoal_set"]) {
        if (goal["status"] == 0 && goal["user"] == participant["id"]) {
          this.tftw.push(goal["name"]);
        } else if (goal["status"] == 1 && goal["user"] == participant["id"]) {
          this.tftd.push(goal["name"]);
        } else if (goal["status"] == 2 && goal["user"] == participant["id"]) {
          this.verify.push(goal["name"]);
        } else if (goal["status"] == 3 && goal["user"] == participant["id"]) {
          this.done.push(goal["name"]);
        } else {
          break;
        }
      }
    }
  }

  getProjectGoals() {
    this._scrumdataService.allProjectGoals(this.project_id).subscribe(
      data => {
        console.log(data);
        this._participants = data["data"];
      },
      error => {
        console.log("error", error);
      }
    );
  }
}
