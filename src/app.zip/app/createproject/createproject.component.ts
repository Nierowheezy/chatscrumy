import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { ScrumdataService } from "../scrumdata.service";
import { Scrumuser, ScrumUserCreateProject } from "../scrumuser";

@Component({
  selector: "app-createproject",
  templateUrl: "./createproject.component.html",
  styleUrls: ["./createproject.component.css"]
})
export class CreateprojectComponent implements OnInit {
  feedback = "";

  ScrumUserCreateProject = new ScrumUserCreateProject("", "", "");

  constructor(
    private _route: ActivatedRoute,
    private _scrumdataService: ScrumdataService
  ) {}

  project_id = 0;
  _participants = [];
  ngOnInit() {
    this.project_id = parseInt(this._route.snapshot.paramMap.get("project_id"));
  }

  onCreateProjectSubmit() {
    console.log(this.ScrumUserCreateProject);
  }
}
